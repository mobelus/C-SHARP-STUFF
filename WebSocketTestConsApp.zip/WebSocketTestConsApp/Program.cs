﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Net;
using System.Net.Sockets;
//using System.Net.WebSockets;
using System.Security.Cryptography;
using System.IO;


namespace WebSocketTestConsApp
{
    /*
        class Program
        {
            static void Main(string[] args)
            {
            }
        }
    */
    //namespace ConsoleWebSocketServer
    //{
        class Program
        {
            const string c_MagicKey = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

            static void Main(string[] args)
            {
                TcpListener l_Listener = new TcpListener(IPAddress.Loopback, 8181);
                l_Listener.Start();
                while (true)
                {
                    using (TcpClient l_Client = l_Listener.AcceptTcpClient())
                    using (NetworkStream l_Stream = l_Client.GetStream())
                    {
                        var l_headers = new Dictionary<string, string>();
                        string l_line = string.Empty;
                        while ((l_line = ReadLine(l_Stream)) != string.Empty)
                        {
                            var tokens = l_line.Split(new char[] { ':' }, 2);
                            if (!string.IsNullOrWhiteSpace(l_line) && tokens.Length > 1)
                            {
                                l_headers[tokens[0]] = tokens[1].Trim();
                            }
                        }

                        string l_secKey = l_headers["Sec-WebSocket-Key"];
                        string l_responseSecKey = ComputeWebSocketHandshakeSecurityHash09(l_secKey);

                        string l_response =
                            "HTTP/1.1 101 Switching Protocols" + Environment.NewLine +
                            "Upgrade: websocket" + Environment.NewLine +
                            "Connection: Upgrade" + Environment.NewLine +
                            "Sec-WebSocket-Accept: " + l_responseSecKey + Environment.NewLine + Environment.NewLine;

                        var l_bufferedResponse = Encoding.UTF8.GetBytes(l_response);
                        l_Stream.Write(l_bufferedResponse, 0, l_bufferedResponse.Length);
                    }
                }
            }

        private static string ReadLine(NetworkStream l_Stream)
        {
            throw new NotImplementedException();
        }

        public static string ComputeWebSocketHandshakeSecurityHash09(string secWebSocketKey)
            {
                string secWebSocketAccept = null; ;
                string l_combinedKey = secWebSocketKey + c_MagicKey;

                SHA1 l_Sha1Crypto = new SHA1CryptoServiceProvider();
                byte[] l_sha1Hash = l_Sha1Crypto.ComputeHash(Encoding.UTF8.GetBytes(l_combinedKey));
                secWebSocketAccept = Convert.ToBase64String(l_sha1Hash);

                return secWebSocketAccept ?? String.Empty;
            }

            static string ReadLine(Stream stream)
            {
                var l_Sb = new StringBuilder();
                var l_buffer = new List<byte>();
                while (true)
                {
                    l_buffer.Add((byte)stream.ReadByte());
                    string l_line = Encoding.ASCII.GetString(l_buffer.ToArray());
                    if (l_line.EndsWith(Environment.NewLine))
                    {
                        return l_line.Substring(0, l_line.Length - 2);
                    }
                }
            }
        }
    //}
}
