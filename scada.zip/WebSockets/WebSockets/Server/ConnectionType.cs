﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebSockets.Server
{
    public enum ConnectionType
    {
        Http,
        WebSocket,
        Unknown
    }
}
